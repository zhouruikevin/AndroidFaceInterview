// 配置信息
module.exports = {
    Token: '34mAT6pXHgus',
    EncodingAESKey: 'F2UIkz3pDXDu0goM9hmMjO',
    OutEndpoint: "http://apiin.im.baidu.com/api/msg/groupmsgsend?access_token=de67eefd619d533032cccd00b37fc4bed"
}